//function paintIt(rule) {
//	var div = $("<div />"), {
//		html: '<style>' + rule + '</style>'
//	}.appendTo('body');
//}
